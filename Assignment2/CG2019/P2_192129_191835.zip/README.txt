Assignment 2

u192129, Leonardo La Rocca, leonardo.larocca01@estudiant.upf.edu

u191835, CHIH-HAO WEI, chihhao.wei01@estudiant.upf.edu 

How to use: 
    Use numbers keys 1-4 to switch between tasks.
    task1: use left click to set vertices for line
    task2: use left click to set first vertex use mouse to move second vertex
    task3: use left click to set circle center, use mouse to set radius and 'F' key to switch between circumference only and filled circle
    task4: use 'Q' and 'W' key to switch between plain and interpolated triangle use left clicks to set vertices use right click to clear vertices
